package webwow.adapters.web;


public class ThingsEndpointException extends RuntimeException {
    public ThingsEndpointException(Throwable t) {
        super(t);
    }
}
